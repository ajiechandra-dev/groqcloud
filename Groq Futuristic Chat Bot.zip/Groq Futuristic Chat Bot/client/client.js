document.addEventListener('DOMContentLoaded', function () {
    const $ = (id) => document.getElementById(id);

    function message(type, text) {
        const el = document.createElement('div');
        el.className = `speech-bubble-${type} color-${type}`;
        el.innerText = text || '';
        document.getElementById('chat').appendChild(el);
        el.scrollIntoView();
        return el;
    }

    async function ask(question) {
        message('human', question);
        $('prompt').blur();
        const url = `http://localhost:3000/chat?${encodeURIComponent(question)}`;
        const el = message('loader');
        el.innerHTML = '<div class=loader></div>';

        try {
            const response = await fetch(url);
            const answer = await response.text();
            message('assistant', answer);
        } catch (e) {
            message('panic', `Something went wrong: ${e.toString()}`);
        } finally {
            el.remove();
            $('prompt').focus();
        }
    }

    $('prompt').addEventListener('keydown', function handleKeyInput(event) {
        if (event.key === 'Enter') {
            const el = $('prompt');
            const question = el.value.trim();
            if (question.length > 0) {
                ask(question);
                el.value = '';
            }
        }
    });

    setTimeout(() => {
        message('assistant', 'Hi, this is Smart Assistant!');
    }, 100);
});